int	assignment(supertype * /*destination*/, supertype * /*source*/);
