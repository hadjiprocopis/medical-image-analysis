histogram	*read_histogram_from_file(char */*filename*/);
