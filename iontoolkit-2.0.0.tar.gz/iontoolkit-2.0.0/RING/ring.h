int	ring(DATATYPE **/*data*/, int /*width*/, int /*distance*/, int /*x*/, int /*y*/, int /*w*/, int /*h*/, int /*W*/, int /*H*/, int /*pixelOut*/, DATATYPE **/*dataOut*/);
