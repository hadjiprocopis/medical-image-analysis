#ifndef _COMBINATORICS_VISITED

int	combinations(int /*n*/, int /*k*/);
int	factorial(int /*x*/);

#define	_COMBINATORICS_VISITED
#endif
