void	sharpen3D(DATATYPE ***/*data*/, int /*x*/, int /*y*/, int /*z*/, int /*w*/, int /*h*/, int /*d*/, DATATYPE ***/*dataOut*/, float /*level*/);
void	laplacian3D(DATATYPE ***/*data*/, int /*x*/, int /*y*/, int /*z*/, int /*w*/, int /*h*/, int /*d*/, DATATYPE ***/*dataOut*/, float /*level*/);
void	sobel3D(DATATYPE ***/*data*/, int /*x*/, int /*y*/, int /*z*/, int /*w*/, int /*h*/, int /*d*/, DATATYPE ***/*dataOut*/, float /*level*/);
void	average3D(DATATYPE ***/*data*/, int /*x*/, int /*y*/, int /*z*/, int /*w*/, int /*h*/, int /*d*/, DATATYPE ***/*dataOut*/, float /*level*/);
void	median3D(DATATYPE ***/*data*/, int /*x*/, int /*y*/, int /*z*/, int /*w*/, int /*h*/, int /*d*/, DATATYPE ***/*dataOut*/, float /*level*/);
void	min3D(DATATYPE ***/*data*/, int /*x*/, int /*y*/, int /*z*/, int /*w*/, int /*h*/, int /*d*/, DATATYPE ***/*dataOut*/, float /*level*/);
void	max3D(DATATYPE ***/*data*/, int /*x*/, int /*y*/, int /*z*/, int /*w*/, int /*h*/, int /*d*/, DATATYPE ***/*dataOut*/, float /*level*/);
void	prewitt3D(DATATYPE ***/*data*/, int /*x*/, int /*y*/, int /*z*/, int /*w*/, int /*h*/, int /*d*/, DATATYPE ***/*dataOut*/, float /*level*/);
