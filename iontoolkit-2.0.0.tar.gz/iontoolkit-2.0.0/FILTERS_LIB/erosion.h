int	erode2D(DATATYPE **/*data*/, int /*x*/, int /*y*/, int /*w*/, int /*h*/, DATATYPE **/*dataOut*/, spec /*thresholdSpec*/);
int	erode_periphery2D(DATATYPE **/*data*/, int /*x*/, int /*y*/, int /*w*/, int /*h*/, DATATYPE **/*dataOut*/, spec /*thresholdSpec*/);
int	dilate2D(DATATYPE **/*data*/, int /*x*/, int /*y*/, int /*w*/, int /*h*/, DATATYPE **/*dataOut*/, spec /*thresholdSpec*/);
int	dilate_periphery2D(DATATYPE **/*data*/, int /*x*/, int /*y*/, int /*w*/, int /*h*/, DATATYPE **/*dataOut*/, spec /*thresholdSpec*/);
