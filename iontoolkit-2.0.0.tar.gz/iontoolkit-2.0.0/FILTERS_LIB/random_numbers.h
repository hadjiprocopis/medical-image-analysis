#ifndef	_RANDOM_NUMBERS_HEADER

#define	_RANDOM_NUMBERS_HEADER

float	random_number_gaussian(float /*mean*/, float /*half_width*/);

#endif

