struct	_TIMESERIES {
	float		*data;			/* the data holder, it contains numPoints data points
						   it should be 
	int		numPoints,		/* number of data points it holds (size of *data) */
			minIndex,		/* 
	float		p_25, p_50, p_75	/* percentiles, 
