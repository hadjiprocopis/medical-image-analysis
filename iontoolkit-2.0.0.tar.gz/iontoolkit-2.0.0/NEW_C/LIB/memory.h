int	_entropy_clustering_allocate_memory(entropyClData */*myData*/);
void	_entropy_clustering_free_memory(entropyClData */*myData*/);
int	_memory_calculator(entropyClData */*myData*/);
