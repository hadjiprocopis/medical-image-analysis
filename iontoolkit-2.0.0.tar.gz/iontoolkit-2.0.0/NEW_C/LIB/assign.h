void	_entropy_clustering_assign_points_to_clusters(entropyClData */*myData*/);
