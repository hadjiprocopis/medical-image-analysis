void	_entropy_clustering_initialise_weights(entropyClData */*myData*/);
void	_entropy_clustering_initialise_clusters(entropyClData */*myData*/);
