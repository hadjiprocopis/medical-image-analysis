void	_entropy_clustering_calculate_derivatives_of_weighting_function_wrt_w(entropyClData */*myData*/);
void	_entropy_clustering_calculate_derivatives_of_distances_with_weights_wrt_w(entropyClData */*myData*/);
void	_entropy_clustering_calculate_derivatives_of_transformed_distance_wrt_w(entropyClData */*myData*/);
void	_entropy_clustering_calculate_derivatives_of_probabilities_wrt_w(entropyClData */*myData*/);
void	_entropy_clustering_calculate_derivatives_of_entropies_wrt_w(entropyClData */*myData*/);
void	_entropy_clustering_calculate_derivatives_of_factors_of_fitness_wrt_w(entropyClData */*myData*/);
void	_entropy_clustering_calculate_derivatives_of_fitness_wrt_w(entropyClData */*myData*/);

