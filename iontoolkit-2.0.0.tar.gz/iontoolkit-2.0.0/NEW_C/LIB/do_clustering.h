void	_do_entropy_clustering_with_weights(entropyClData */*myData*/);
void	_do_entropy_clustering_without_weights(entropyClData */*myData*/);

