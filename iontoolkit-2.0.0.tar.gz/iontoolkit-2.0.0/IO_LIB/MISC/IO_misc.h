#ifndef _IO_MISC
#define	_IO_MISC

int	check_system_endianess(void);

#endif
