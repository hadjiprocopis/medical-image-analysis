int	write_unc_slice_to_RGB_tiff_file(DATATYPE **/*data*/, int /*width*/, int /*height*/, char */*filename*/);
int	write_unc_slice_to_grayscale_tiff_file(DATATYPE **/*data*/, int /*width*/, int /*height*/, char */*filename*/);
int	write_RGB_to_RGB_tiff_file(DATATYPE **/*R*/, DATATYPE **/*G*/, DATATYPE **/*B*/, int /*width*/, int /*height*/, char */*filename*/);
